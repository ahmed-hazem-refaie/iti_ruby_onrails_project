class Group < ApplicationRecord
  belongs_to :owner
end
