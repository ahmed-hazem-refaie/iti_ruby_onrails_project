class Activite < ApplicationRecord
  belongs_to :user
end
